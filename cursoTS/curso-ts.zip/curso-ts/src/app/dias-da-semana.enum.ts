export enum DiasDaSemana {
    seg = 'Segunda',
    ter = 'Terça',
    qua = 'Quarta',
    qui = 'Quinta',
    sex = 'Sexta',
    sab = 'Sabádo',
    dom = 'Domingo'
}
